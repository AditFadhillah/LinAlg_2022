The language steeings are those of Python 3.6 or higher.
This should run on Windows, Linux and macOS if Python is installed properly (using for instance Anaconda or Miniconda). 


* To execute your code, navigate to ProjectA folder and
  C:\FolderPath> python TestProjectA.py

* This code was written by François Lauze (francois@di.ku.dk).
